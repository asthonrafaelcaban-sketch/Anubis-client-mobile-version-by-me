package net.anubis.client.util;

import java.io.File;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * Detects Android launchers (PojavLauncher, Zalith, FCL, MobileGlues builds, ...) and
 * the desktop-only pieces they usually lack (java.awt natives, tinyfd, native media APIs).
 *
 * Force on/off with -Danubis.mobile=true|false and -Danubis.awt=true|false.
 */
@Environment(EnvType.CLIENT)
public final class MobileSupport {
    private static final boolean MOBILE = detectMobile();
    private static volatile Boolean awt;

    private MobileSupport() {
    }

    public static boolean isMobile() {
        return MOBILE;
    }

    /** True only if java.awt can really draw (needs libawt/libfontmanager, which Android JREs usually lack). */
    public static boolean hasAwt() {
        Boolean cached = awt;
        if (cached == null) {
            cached = probeAwt();
            awt = cached;
        }
        return cached;
    }

    /** Same result as java.awt.Color.HSBtoRGB, without loading java.awt. */
    public static int hsbToRgb(float hue, float saturation, float brightness) {
        int r = 0;
        int g = 0;
        int b = 0;
        if (saturation == 0.0F) {
            r = g = b = (int)(brightness * 255.0F + 0.5F);
        } else {
            float h = (hue - (float)Math.floor(hue)) * 6.0F;
            float f = h - (float)Math.floor(h);
            float p = brightness * (1.0F - saturation);
            float q = brightness * (1.0F - saturation * f);
            float t = brightness * (1.0F - saturation * (1.0F - f));
            switch ((int)h) {
                case 0 -> { r = c(brightness); g = c(t); b = c(p); }
                case 1 -> { r = c(q); g = c(brightness); b = c(p); }
                case 2 -> { r = c(p); g = c(brightness); b = c(t); }
                case 3 -> { r = c(p); g = c(q); b = c(brightness); }
                case 4 -> { r = c(t); g = c(p); b = c(brightness); }
                default -> { r = c(brightness); g = c(p); b = c(q); }
            }
        }

        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    private static int c(float v) {
        return (int)(v * 255.0F + 0.5F);
    }

    private static boolean detectMobile() {
        String forced = System.getProperty("anubis.mobile");
        if (forced != null) {
            return Boolean.parseBoolean(forced);
        }

        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String vendor = (System.getProperty("java.vendor", "") + System.getProperty("java.vm.vendor", "")).toLowerCase(Locale.ROOT);
        if (os.contains("android") || vendor.contains("android")) {
            return true;
        }

        for (String key : new String[]{"POJAV_RENDERER", "POJAV_NATIVEDIR", "POJAV_ENV", "FCL_NATIVEDIR", "ZALITH_RENDERER", "ANDROID_ROOT", "ANDROID_DATA"}) {
            if (System.getenv(key) != null) {
                return true;
            }
        }

        return os.contains("linux") && new File("/system/build.prop").exists();
    }

    private static boolean probeAwt() {
        String forced = System.getProperty("anubis.awt");
        if (forced != null) {
            return Boolean.parseBoolean(forced);
        }

        if (!MOBILE) {
            return true;
        }

        try {
            java.awt.image.BufferedImage image = new java.awt.image.BufferedImage(2, 2, java.awt.image.BufferedImage.TYPE_INT_ARGB);
            java.awt.Graphics2D g = image.createGraphics();
            g.setFont(new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 12));
            g.getFontMetrics().stringWidth("A");
            g.dispose();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}

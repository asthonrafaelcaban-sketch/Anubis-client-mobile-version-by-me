package net.anubis.client.gui;

import net.anubis.client.util.MobileSupport;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;

/**
 * Touch devices have no Right Shift key. On mobile, adds an "Anubis" button to the pause menu
 * that opens the click GUI (the key bind still works if the launcher maps one).
 */
@Environment(EnvType.CLIENT)
public final class MobileEntry {
    private MobileEntry() {
    }

    public static void install() {
        if (MobileSupport.isMobile()) {
            ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
                if (screen instanceof PauseScreen) {
                    Screens.getButtons(screen)
                        .add(Button.builder(Component.literal("Anubis"), button -> client.setScreen(new ImGuiScreen())).bounds(6, 6, 90, 24).build());
                }
            });
        }
    }
}
